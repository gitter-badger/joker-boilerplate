

exports.project = {
  name: 'Joker - Boilerplate',
  dev: 'src',
  tmp: '.tmp',
  dest: 'dist'
};
