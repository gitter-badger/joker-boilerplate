'use strict';

var conf = require('./config');
var gulp = require('gulp');
var wiredep = require('wiredep').stream;

gulp.task('bower', function () {

  gulp.src(conf.project.dev + '/**/*.html')
  .pipe(wiredep({
    directory: conf.project.dev + '/bower_components',
    ignorePath: /^(\.\.\/)*\.\./
  }))
  .pipe(gulp.dest(conf.project.dev));

});


