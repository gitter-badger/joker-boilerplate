'use strict';

var conf = require('./config');
var gulp = require('gulp');

