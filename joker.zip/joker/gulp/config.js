

exports.project = {
  name: 'Joker - Javascript Framework',
  dev: 'src',
  tmp: '.tmp',
  dest: 'dist'
};
